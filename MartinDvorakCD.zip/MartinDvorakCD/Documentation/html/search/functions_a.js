var searchData=
[
  ['levensteindistance',['LevensteinDistance',['../class_crypto_1_1_function_testing.html#a88a16df256e6d63d43fbbb3b5c644f29',1,'Crypto::FunctionTesting']]],
  ['longestperiod',['LongestPeriod',['../class_testing_1_1_search_longest.html#ab0c6b6cb67d56bd5d739b41bd71590ee',1,'Testing::SearchLongest']]]
];
