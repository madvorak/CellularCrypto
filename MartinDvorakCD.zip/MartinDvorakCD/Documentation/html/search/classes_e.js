var searchData=
[
  ['totalistic2dautomaton',['Totalistic2DAutomaton',['../class_cellular_1_1_totalistic2_d_automaton.html',1,'Cellular']]],
  ['totalistic2dautomatoninteractive',['Totalistic2DAutomatonInteractive',['../class_cellular_1_1_totalistic2_d_automaton_interactive.html',1,'Cellular']]],
  ['totalisticternarytest',['TotalisticTernaryTest',['../class_testing_1_1_totalistic_ternary_test.html',1,'Testing']]]
];
